%% Function implemention of channel estimation presented in ISUT 2015 paper.
%% Copyright Ananya Sen Gupta, Naushad Ansari and Anubha Gupta, 2015.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% A. Sen Gupta, N. Ansari, and A. Gupta, �Tracking the underwater acoustic channel
% %% using two-dimensional frequency sampling,� IEEE OES International Symposium on 
% %% Underwater Technology 2015, Feb. 2015,Chennai, India.

% %% Other refence, JASA: N. Ansari, A. Gupta, and A. S. Gupta,�Shallow water acoustic channel
% %% estimation using two-dimensional frequency characterization,� The Journal of the 
% %% Acoustical Society of America (JASA), 2016.

function avgNmseRec=Function_Implementing_ISUT2015(tracked_channel,K,L,maxIter,snrSig)

lenL = length(L);             % length of L vector (number of Doppler frequencies)
options.verbosity=0;
%% Some initialization
avgNmseRec = zeros(lenL,1);   % Average NMSE of the reconstructed channel over 'maxIter' 
                              % iterations at different 'L'
NmseRec = zeros(maxIter,1);   % NMSE of reconstructed channel at different iteration
 
%% Experiment starts here
for k1=1:lenL                               % Iterate for all Doppler frequencies range
    
    orgH = tracked_channel(1:K+L(k1)-1,:);  % We assume that 'orgH' represent original 
                                            % channel (ground truth)
    ogH_C = orgH(K:K+L(k1)-1,1:K);          % For calculation purpose

    %% Generate input signal x
    clear i f;                              % i - time instant, f - delay frequency
                       
    i = 0:1:K+L(k1)-2; 
    f = 0:1:K-1;
    x = zeros(K+L(k1)-1,K);                 % initizaling input signal as zero matrix       
    for k = 1:1:K                           % Generate input signal for every delay frequecy 'k'
         x(:,k) = exp(1j*2*pi*f(k)*i/K);
    end

    %% Generate output signal y(i,f)=y(i,k)
    clear i f ;
    y = zeros(L(k1),K);                     % initialize output signal as zero matrix
    for i = 1:1:L(k1)
        for f = 1:1:K
            for k = 1:1:K                   % equation (1) of paper
                y(i,f) = y(i,f)+orgH(K+i-1,k)*x(K+i-k,f);
            end
        end
    end

    %% Iterate for 'maxIter' iterations with different noise
    for iter = 1:maxIter
            
        display(sprintf('Running for %dth iteration of win Len %d',iter,L(k1))); 
        %% Generate noisy y for signal SNR 'snrSig' (For SNR, please refer eq. (11) of JASA paper mentioned in main code)
        ener_y = norm(y(:))^2;                   % Energy of output signal y
        ener_n = ener_y/(10^(snrSig/10));        % Energy of noise
        var_n = ener_n/length(y(:));             % Noise variance
        y_noisy = y+sqrt(var_n)*complex(randn(L(k1),K),randn(L(k1),K))/sqrt(2);
                                                 % noisy received signal
                
        %% Compute Y so that it looks like 1-D DFT along the delay dimension (refer noisy version of eq. (2) of paper)
        noisyY = zeros(L(k1),K);  
        clear i f;
        for i = 1:1:L(k1)
            for f = 1:1:K
                noisyY(i,f) = y_noisy(i,f)*exp(-1j*2*pi*(K+i-2)*(f-1)/K);
            end
        end
        
        %% compute 1-D FFT along each column (refer eq. (3) of paper)
        noisyU = fft(noisyY,[],1);
        noisyU = (1/sqrt(L(k1)*K))*noisyU; % normalize NoisyU

        %% Estimate H from noisyU using solver spgl1
        F = FFT2(L(k1),K);                       % FFT operator
        tau = 1.5*sqrt(L(k1)*K);                 % measure of sparsity
        % 1.5*sqrt(L(k1)*K) is found to be optimal for channel
        % estimation with this method.
        recH = spg_lasso(F,noisyU(:),tau,options);       % LASSSO is solved instead of BPDN
        % BPDN and LASSO are equivalent to each other and, hence either be solved for solution
        recH = reshape(recH,L(k1),K);
        NmseRec(iter) = calNMSEdB(ogH_C,recH,0); % Check reconstruction accuracy in terms of NMSE
    end

    %% Calculate average NMSE over 'maxIter' iterations
    avgNmseRec(k1) = mean(NmseRec);
end

%% END of function