function op = FFT2(m,n)

op = @(x,mode) FFT2_intrnl(m,n,x,mode);


function y = FFT2_intrnl(m,n,x,mode)
if mode == 0
   y = {m*n,m*n,[1,1,1,1],{'FFT2'}};
elseif mode == 1
   y = reshape( fft2(reshape(x,m,n)) / sqrt(m*n), m*n, 1);
else
   y = reshape(ifft2(reshape(x,m,n)) * sqrt(m*n), m*n, 1);
end
