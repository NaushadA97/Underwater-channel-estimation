%% Copyright Ananya Sen Gupta, Naushad Ansari and Anubha Gupta, 2015.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% A. Sen Gupta, N. Ansari, and A. Gupta, �Tracking the underwater acoustic channel
% %% using two-dimensional frequency sampling,� IEEE OES International Symposium on 
% %% Underwater Technology 2015, Feb. 2015,Chennai, India.

% %% Other refence, JASA: Ansari, Naushad, Anubha Gupta, and Ananya Sen Gupta. 
% %% "Shallow water acoustic channel estimation using two-dimensional frequency
% %% characterization." The Journal of the Acoustical Society of America 140.5 
% %% (2016): 3995-4009.
clc;
clear all;
close all;

addpath(genpath('Supporting functions'));
addpath(genpath('spgl1-1.8'));

%% Parameters
K = 200;                      % number of delay frequencies as mentioned in paper
                              % (or number of delay taps)
L = 20:10:150;                % define a range of Doppler frequencies for sampling the  
                              % channel in Doppler domain (dual to time domain) 
maxIter = 1;                % Nnumber of iterations for the experiment
snrSig = 10;                  % snr of the noisy channel 

%% Load your channel (ground truth) here
load('tracked_channel.mat');  % tracked_channel contains the original channel            
                                          
%% Call main function 

NmseRec=Function_Implementing_ISUT2015(tracked_channel,K,L,maxIter,snrSig);
                              % NMSE of reconstructed channel

%% Plot results
plot(L,NmseRec,'k');
title('Channel reconstruction results in terms of NMSE','FontSize',14);
xlabel('Window Length','FontSize',14);
ylabel('NMSE (in dB)','FontSize',14);
