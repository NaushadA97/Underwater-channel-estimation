%% Copyright Naushad Ansari, Anubha Gupta and Ananya Sen Gupta, 2016.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% Ansari, Naushad, Anubha Gupta, and Ananya Sen Gupta. "Shallow water acoustic
% %% channel estimation using two-dimensional frequency characterization." The 
% %% Journal of the Acoustical Society of America 140.5 (2016): 3995-4009.
clc;
clear all;
close all;

addpath(genpath('Supporting functions'));
addpath(genpath('spgl1-1.8'));

%% Parameters
K = 200;                      % number of delay frequencies as mentioned in paper
                              % (or number of delay taps)
L = 50:10:150;                % define a range of Doppler frequencies for sampling the  
                              % channel in Doppler domain (dual to time domain) 
SampRat = 40:10:100;          % define a range of samling ratios for experiment 
maxIter = 200;                % Number of iterations for the experiment
snrSig = 10;                  % snr of the noisy channel 

% Run for L=50:10:150 and SampRat=40:10:100 to produce paper results

%% Load your channel (ground truth) here        
load('Simulated_channel.mat');        % load simulated channel
tracked_channel=hmat';


%% Call main functions 
% Modified-CS (Fig. 23 and 24 of paper)
clc;
display(sprintf('Implementation of channel estimation using modeified CS starting now'));
pause(3);                              
NmseRec_ModifiedCS=Function_Implementing_JASA2016_ModifiedCS_ForSimulatedChannel(tracked_channel,K,L,...
    SampRat,maxIter,snrSig);
                                
%% Plot results
PlotResults_ForSimulatedChannel(NmseRec_ModifiedCS);