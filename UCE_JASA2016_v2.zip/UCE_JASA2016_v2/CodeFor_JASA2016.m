%% Copyright Naushad Ansari, Anubha Gupta and Ananya Sen Gupta, 2016.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% Ansari, Naushad, Anubha Gupta, and Ananya Sen Gupta. "Shallow water acoustic
% %% channel estimation using two-dimensional frequency characterization." The 
% %% Journal of the Acoustical Society of America 140.5 (2016): 3995-4009.
clc;
clear all;
close all;

addpath(genpath('Supporting functions'));
addpath(genpath('spgl1-1.8'));

%% Parameters
K = 200;                      % number of delay frequencies as mentioned in paper
                              % (or number of delay taps)
L = 20:10:150;                % define a range of Doppler frequencies for sampling the  
                              % channel in Doppler domain (dual to time domain) 
SampRat = 40:10:100;          % define a range of samling ratios for experiment 
maxIter = 200;                % Number of iterations for the experiment
snrSig = 10;                  % snr of the noisy channel 

% Run for L=20:10:150 and SampRat=40:10:100 to produce paper results

%% Load your channel (ground truth) here
load('tracked_channel.mat');  % tracked_channel contains the original full channel            
                                          
%% Call main functions 
% Basic CS (Fig. 7 and 8 of paper)
display(sprintf('Implementation of channel estimation using basic CS starting now'));
pause(3);
NmseRec_BasicCS = Function_Implementing_JASA2016_BasicCS(tracked_channel,K,L,...
    SampRat,maxIter,snrSig);                              
                              % NMSE of reconstructed channel

% CS with prior information (Fig. 9 to 12 of paper)
clc;
display(sprintf('Implementation of channel estimation using CS with prior information starting now'));
pause(3);                              
FixedDopp=0;
% FixedDopp-- number of Doppler frequencies to be fixed apart from zero Doppler
% keep it 0, 1 and 2 to produce results of Fig. 10, 11 and 12 respectively
% at 5dB of signal SNR.
NmseRec_CSwithPriorInfo=Function_Implementing_JASA2016_CSwithPriorInfo(tracked_channel,K,L,...
    SampRat,maxIter,snrSig,FixedDopp);

% Modified-CS (Fig. 16 and 17 of paper)
clc;
display(sprintf('Implementation of channel estimation using modeified CS starting now'));
pause(3);                              
NmseRec_ModifiedCS=Function_Implementing_JASA2016_ModifiedCS(tracked_channel,K,L,...
    SampRat,maxIter,snrSig);
                                
%% Plot results
PlotResults(NmseRec_BasicCS);
figure;
PlotResults(NmseRec_CSwithPriorInfo);
figure;
PlotResults(NmseRec_ModifiedCS);