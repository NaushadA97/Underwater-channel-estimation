
function PlotResults_ForSimulatedChannel(NMSE)
WL=50:10:150;    % window length

plot(WL,NMSE(:,1),'k','LineWidth',1,'marker','.');
hold on;
plot(WL,NMSE(:,2),'--k','LineWidth',1,'marker','*');
hold on;
plot(WL,NMSE(:,3),'k','LineWidth',1,'marker','s');
hold on;
plot(WL,NMSE(:,4),'--k','LineWidth',1,'marker','p');
hold on;
plot(WL,NMSE(:,5),'k','LineWidth',1,'marker','d');
hold on;
plot(WL,NMSE(:,6),'--k','LineWidth',1,'marker','o');
hold on;
plot(WL,NMSE(:,7),'k','LineWidth',1,'marker','x');

xlabel('Window Length','FontSize',14);
ylabel('NMSE of reconstructed channel in dB','FontSize',14);
legend({'Sampling ratio 40%','50%','60%','70%','80%','90%','100%'},'FontSize',12)
