function op = MyRestriction(n,idx)

if (min(idx) < 1) || (max(idx) > n)
   error('Index parameter must be integer and match dimensions of the operator');
end

op = @(x,mode) MyRestriction_intrnl(n,idx,x,mode);

function y = MyRestriction_intrnl(n,idx,x,mode)
m = length(idx);

if mode == 0
   y = {m,n,[0,1,0,1],{'Restriction'}};
elseif mode == 1
   y = x(idx);
else
   y = zeros(n,1);
   y(idx) = x;
end
