%% Copyright Naushad Ansari, Anubha Gupta and Ananya Sen Gupta, 2016.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% Ansari, Naushad, Anubha Gupta, and Ananya Sen Gupta. "Shallow water acoustic
% %% channel estimation using two-dimensional frequency characterization." The 
% %% Journal of the Acoustical Society of America 140.5 (2016): 3995-4009.

%% Function for the implementation of 'Modified-CS' in JASA 2016 (above) for simulated channel

function avgNmseRec=Function_Implementing_JASA2016_ModifiedCS_ForSimulatedChannel(tracked_channel,K,L,...
    SampRat,maxIter,snrSig)

lenL = length(L);                      % length of L vector (number of Doppler frequencies)
lenSampRat = length(SampRat);          % number of sampling ratios
options.verbosity = 0;

%% Some initialization
avgNmseRec = zeros(lenL,lenSampRat);   % Average NMSE of the reconstructed channel over 'maxIter' 
                                       % iterations at different 'L' and 'SampRat'
NmseRec = zeros(maxIter,1);            % NMSE of reconstructed channel at different iterations

% Iterate for all Doppler frequencies range
for k1=1:lenL                          
    
    orgH = tracked_channel(1:K+L(k1)-1,1:K);  % We assume that 'orgH' represent original 
                                              % channel (ground truth)
    ogH_C = orgH(K:K+L(k1)-1,1:K);            % For calculation purpose

    %% Generate input signal x
    clear i f;                                % i - time instant, f - delay frequency
                       
    i = 0:1:K+L(k1)-2; 
    f = 0:1:K-1;
    x = zeros(K+L(k1)-1,K);                   % initizaling input signal as zero matrix       
    for k = 1:1:K                             % Generate input signal for every delay frequecy 'k'
         x(:,k) = exp(1j*2*pi*f(k)*i/K);
    end

    %% Generate output signal y(i,f)=y(i,k)
    clear i f ;
    y = zeros(L(k1),K);                       % initialize output signal as zero matrix
    for i = 1:1:L(k1)
        for f = 1:1:K
            for k = 1:1:K                     % equation (1) of paper
                y(i,f) = y(i,f)+orgH(K+i-1,k)*x(K+i-k,f);
            end
        end
    end
    
    %% Iterate for all sampling ratios
    L1 = L(k1)*SampRat/100;
    for k2 = 1:lenSampRat  
        
        %% Iterate 'maxIter' times for denoising
        for iter = 1:maxIter
            
            display(sprintf('Running for %dth iteration of win Len %d and Sampling ratio %d',iter,L(k1),SampRat(k2)));             
            %% Generate noisy y for signal SNR 'snrSig' (For SNR, please refer eq. (11) of paper)
            ener_y = norm(y(:))^2;                   % Energy of output signal y
            ener_n = ener_y/(10^(snrSig/10));        % Energy of noise
            var_n = ener_n/length(y(:));             % Noise variance
            y_noisy = y+sqrt(var_n)*complex(randn(L(k1),K),randn(L(k1),K))/sqrt(2);
                                                     % noisy received signal         
            %% Compute Y so that it looks like 1-D DFT along the delay dimension (refer noisy version of eq. (2) of paper)
            noisyY = zeros(L(k1),K);
            clear i f;
            for i = 1:1:L(k1)
                for f = 1:1:K
                    noisyY(i,f) = y_noisy(i,f)*exp(-1j*2*pi*(K+i-2)*(f-1)/K);
                end
            end

            %% compute 1-D FFT along each column (refer eq. (3) of paper)
            noisyU = fft(noisyY,[],1);
            noisyU = (1/sqrt(L(k1)*K))*noisyU;      % normalize NoisyU
            
            %% Estimate U from noisyU using solver spgl1 (Modified-CS)
            F = FFT2(L(k1),K);                        % FFT operator
            NumFixedRow = 6;                          % number of doppler to be fixed from both sides
            UprFxdRow = noisyU(1:NumFixedRow,:);      % positive Doppler frequencies to be fixed
            LowFxdRow = noisyU(end-NumFixedRow+1:end,:); % negative Doppler frequencies to be fixed
            noisyU_rest = noisyU(NumFixedRow+1:end-NumFixedRow,:);  % rest of Doppler freq.
            idx = FindIndex_ForBasicCS(L(k1)-2*NumFixedRow,L1(k2)-2*NumFixedRow,K);
            R = MyRestriction((L(k1)-2*NumFixedRow)*K,idx);         % operator R_Tc of paper
            noisyU_rest_sub = R(noisyU_rest(:),1);                  % subsampled noisyU_rest
            tau = 0.002*sqrt(L(k1)*K); 
            % 0.002*sqrt(L(k1)*K) is found to be optimal for channel
            % estimation (with simulated channel) with Modified-CS.
            recU_rest = spg_lasso(R,noisyU_rest_sub(:),tau,options);
            recU_rest = reshape(recU_rest,L(k1)-2*NumFixedRow,K);
            recU = [UprFxdRow;recU_rest;LowFxdRow];               % Combine +ve and -ve Doppler frequencies 
                                                                  % with rest of the reconstructed U 
            recH = F(recU(:),2);                     % eq. (4)
            NmseRec(iter) = calNMSEdB(ogH_C,recH,0); % Check reconstruction accuracy in terms of NMSE
        end
        %% Calculate average NMSE over 'maxIter' iterations
        avgNmseRec(k1,k2)=mean(NmseRec);
    end
end
%% END of function