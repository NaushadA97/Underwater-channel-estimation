%% Copyright Naushad Ansari, Anubha Gupta and Ananya Sen Gupta, 2015.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% N. Ansari, A. Gupta, and A. Sen Gupta, "Physics inspired CS based underwater
% %% acoustic channel estimation," in IEEE Global Conference on Signal and
% %% Information Processing (GlobalSIP), pp. 1106:1110, 2015. 

clc;
clear all;
close all;

addpath(genpath('Supporting functions'));
addpath(genpath('spgl1-1.8'));

%% Parameters
K = 200;                      % number of delay frequencies as mentioned in paper
                              % (or number of delay taps)
L = 20:10:150;                % define a range of Doppler frequencies for sampling the  
                              % channel in Doppler domain (dual to time domain) 
SampRat = 40:10:100;          % define a range of samling ratios for experiment 
maxIter = 200;                % Number of iterations for the experiment
snrSig = 5;                   % snr of the noisy channel 

% Run for L=20:10:150 and SampRat=40:10:100 to produce paper results

%% Load your channel (ground truth) here
load('tracked_channel.mat');  % tracked_channel contains the original full channel            
                                          
%% Call main function 
% Basic CS (Fig. 2 and 4 of paper)
display(sprintf('Implementation of basic CS starting now'));
pause(3);
NmseRec_BasicCS = Function_Implementing_GlobalSip2015_BasicCS(tracked_channel,K,L,...
    SampRat,maxIter,snrSig);                              
                              % NMSE of reconstructed channel

clc;
display(sprintf('Implementation of proposed method starting now'));
pause(3);                              
% Proposed method (Fig. 3 and 5 of paper)
FixedDopp=2;                  % FixedDopp=2 for paper results
% FixedDopp-- number of Doppler frequencies to be fixed apart from zero Doppler
NmseRec_ProposedMethod=Function_Implementing_GlobalSip2015_proposedMethod(tracked_channel,K,L,...
    SampRat,maxIter,snrSig,FixedDopp);
                                
%% Plot results
PlotResults(NmseRec_BasicCS);
figure;
PlotResults(NmseRec_ProposedMethod);
