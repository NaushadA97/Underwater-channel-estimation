%% Copyright Naushad Ansari, Anubha Gupta and Ananya Sen Gupta, 2015.
% %% Please feel free to use this open-source code for research purposes only. 
% %%
% %% Please cite the following paper while using the results:
% %%
% %% N. Ansari, A. Gupta, and A. Sen Gupta, �Physics inspired CS based underwater
% %% acoustic channel estimation,� in IEEE Global Conference on Signal and
% %% Information Processing (GlobalSIP), pp. 1106�1110, 2015. 

%% Function for Basic CS implementation presented in GlobalSip 2015 (above)

function avgNmseRec=Function_Implementing_GlobalSip2015_BasicCS(tracked_channel,K,L,SampRat,maxIter,snrSig)

lenL = length(L);                      % length of L vector (number of Doppler frequencies)
lenSampRat = length(SampRat);          % number of sampling ratios
options.verbosity=0;

%% Some initialization
avgNmseRec = zeros(lenL,lenSampRat);   % Average NMSE of the reconstructed channel over 'maxIter' 
                                       % iterations at different 'L' and 'SampRat'
NmseRec = zeros(maxIter,1);            % NMSE of reconstructed channel at different iterations

% Iterate for all Doppler frequencies range
for k1=1:lenL                          
    
    orgH = tracked_channel(1:K+L(k1)-1,:);  % We assume that 'orgH' represent original 
                                            % channel (ground truth)
    ogH_C = orgH(K:K+L(k1)-1,1:K);          % For calculation purpose

    %% Generate input signal x
    clear i f;                              % i - time instant, f - delay frequency
                       
    i = 0:1:K+L(k1)-2; 
    f = 0:1:K-1;
    x = zeros(K+L(k1)-1,K);                 % initizaling input signal as zero matrix       
    for k = 1:1:K                           % Generate input signal for every delay frequecy 'k'
         x(:,k) = exp(1j*2*pi*f(k)*i/K);
    end

    %% Generate output signal y(i,f)=y(i,k)
    clear i f ;
    y = zeros(L(k1),K);                     % initialize output signal as zero matrix
    for i = 1:1:L(k1)
        for f = 1:1:K
            for k = 1:1:K                   % equation (1) of paper
                y(i,f) = y(i,f)+orgH(K+i-1,k)*x(K+i-k,f);
            end
        end
    end
    
    %% % Iterate for all sampling ratios
    L1=L(k1)*SampRat/100;
    for k2=1:lenSampRat  
        
        %% Iterate 'maxIter' times for denoising
        for iter=1:maxIter
            
            display(sprintf('Running for %dth iteration of win Len %d and Sampling ratio %d',iter,L(k1),SampRat(k2))); 
            %% Generate noisy y for signal SNR 'snrSig' (For SNR, please refer eq. (12) of paper)
            ener_y = norm(y(:))^2;                   % Energy of output signal y
            ener_n = ener_y/(10^(snrSig/10));        % Energy of noise
            var_n = ener_n/length(y(:));             % Noise variance
            y_noisy = y+sqrt(var_n)*complex(randn(L(k1),K),randn(L(k1),K))/sqrt(2);
                                                     % noisy received signal         
            %% Compute Y so that it looks like 1-D DFT along the delay dimension (refer noisy version of eq. (3) of paper)
            noisyY = zeros(L(k1),K);
            clear i f;
            for i = 1:1:L(k1)
                for f = 1:1:K
                    noisyY(i,f) = y_noisy(i,f)*exp(-1j*2*pi*(K+i-2)*(f-1)/K);
                end
            end

            %% compute 1-D FFT along each column (refer eq. (4) of paper)
            noisyU = fft(noisyY,[],1);
            noisyU = (1/sqrt(L(k1)*K))*noisyU;      % normalize NoisyU
            
            %% Estimate U from noisyU using solver spgl1
            F = FFT2(L(k1),K);                         % FFT operator
            idx = FindIndex_ForBasicCS(L(k1),L1(k2),K);% find indexes to be sampled, eq. (8) of paper
            R = MyRestriction(L(k1)*K,idx);            % operator phi of paper
            noisyU_obs = R(noisyU(:),1);               % observed noisyU, (eq. (9) of paper)
            tau = 0.5*sqrt(L(k1)*K);                 
            % 0.5*sqrt(L(k1)*K) is found to be optimal for channel
            % estimation with this method.
            recU = spg_lasso(R,noisyU_obs(:),tau,options);  % LASSSO is solved instead of BPDN
            % BPDN and LASSO are equivalent to each other and, hence either be solved for solution
            recU = reshape(recU,L(k1),K);
            recH = F(recU(:),2);                       % eq. (5)
            NmseRec(iter) = calNMSEdB(ogH_C,recH,0);   % Check reconstruction accuracy in terms of NMSE
        end

        %% Calculate average NMSE over 'maxIter' iterations
        avgNmseRec(k1,k2)=mean(NmseRec);
    end
end

%% END of function