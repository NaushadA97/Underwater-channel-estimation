%% This function finds the indexes for sampling the channel (as per the sampling 
% opertor phi_R of paper) to form operator phi_R. 
% Assuming that zero Doppler is always fixed and FixedDopp gives other number of 
% Doppler frequencies to be fixed.
% FixedDopp-- number of Doppler frequencies to be fixed apart from zero Doppler.
function idx=FindIndex_ToFormOperator_phi_R(L,K,L1,FixedDopp)

if FixedDopp==0
    idx00=(0:1:K-1)*L+1;
    idx01=(0:1:K-1)*L;
    for i=1:1:K
        temp01(:,i)=idx01(i)+[2:L];
    end
    idx02=temp01(:);
    temp02=randperm(length(idx02));
    temp03=sort(temp02(1:(L1-1)*K));
    idx03=idx02(temp03);
    idx=[idx00 idx03'];
    idx=sort(idx,'ascend');
else
    idx0=(0:1:K-1)*L+1;
    idx1=(0:1:K-1)*L;
    for i=1:1:K;
        temp1(:,i)=idx1(i)+[2:FixedDopp+1];
    end
    idx1=temp1(:);

    idx2=(0:1:K-1)*L;
    for i=1:1:K
        temp2(:,i)=idx2(i)+[FixedDopp+2:L-FixedDopp];
    end
    idx2=temp2(:);

    idx3=(0:1:K-1)*L;
    for i=1:1:K
        temp3(:,i)=idx3(i)+[L-FixedDopp+1:L];
    end
    idx3=temp3(:);

    temp=randperm(length(idx2));
    temp=sort(temp(1:(L1-2*FixedDopp-1)*K));
    idx4=idx2(temp);
    idx=[idx0 idx1' idx4' idx3'];
    idx=sort(idx,'ascend');
    idx=idx';
    
end