%% This function find the indexes of the samples to be captured randomly as per
% basic CS. Function finds indexes for L1*K (as per sampling ratio) no of samples
% out of L*K  samples of the channel.
function idx1=FindIndex_ForBasicCS(L,L1,K)

idx=randperm(L*K);
idx1=sort(idx(1:L1*K));

