%% This function calculates the NMSE(normlaized mean squared error of the image recImg,
% with reference to the original image img. boun is the boundary left at 
% the corners for NMSE calculation.
% Required Formula= 10log10(||img-recImg||/||img||)
function nmse=calNMSEdB(img,recImg,boun)

img=img(boun+1:end-boun,boun+1:end-boun);
recImg=recImg(boun+1:end-boun,boun+1:end-boun);
mse=norm(img(:)-recImg(:),2)^2;
ener_s=norm(img(:),2)^2;
nmse=10*log10(mse/ener_s);