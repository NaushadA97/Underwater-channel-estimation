%% This function calculates the SNR of the image recImg, with reference 
% to the original image img. boun is the boundary left at the corners for 
% SNR calculation. The image can be complex
% SNR is calculated as per the Gonzalez book.


function snr1=calSNRC(img,recImg,boun)

img=img(boun+1:end-boun,boun+1:end-boun);
recImg=recImg(boun+1:end-boun,boun+1:end-boun);
sig=norm(img(:))^2;
err=norm(img(:)-recImg(:))^2;
snr1=10*log10(sig/err);